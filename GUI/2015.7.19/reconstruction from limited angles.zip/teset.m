angle=0;
ee=sino(:,angle+1);
eee=es_sino(:,angle+1);
ee1=ee*65;
hold on
plot(s,ee1,'r')
plot(s,eee,'g')
