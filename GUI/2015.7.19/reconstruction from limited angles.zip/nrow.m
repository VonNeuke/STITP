function n = nrow(x)

%	function n = nrow(x)
%	Return number of rows in x.

	n = size(x); n = n(1);
