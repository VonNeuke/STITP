function result=v_r2_0(r,p,n,m,v_r_0)
result=(-1)*(p+n+m+r+1)*(p-n-m-r)*v_r_0;
temp=(r+2)*(2*m+r+3);
result=result/temp;


